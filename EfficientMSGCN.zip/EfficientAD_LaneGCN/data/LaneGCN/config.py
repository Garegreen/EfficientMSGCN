import math

data_config = {
    'rot_aug': False,
    'pred_range': [-100.0, 100.0, -100.0, 100.0],
    'num_scales': 6,
    'cross_dist': 6,
    'cross_angle': None,
}
